package com.example.simplenote.ui.settings

import com.example.simplenote.ui.components.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import com.example.simplenote.ui.theme.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.simplenote.R

@Composable
fun SettingsScreen(
    uiState: SettingsUiState,
    name: String,
    email: String,
    onBack: () -> Unit,
    onChangePassword: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        TopBar("Settings", onBack= onBack)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ){
            ProfileSection(
                imageRes = AppIcons.Profile,
                name = name,
                email = email
            )
            HorizontalDivider(thickness = 1.dp, color = LightGray)
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ){
                Text(
                    text = "APP SETTINGS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight(400),
                    color = DarkGray
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(start = 8.dp, end = 8.dp)
                        .align(Alignment.Start),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppLabel(
                        "Change Password",
                        AppIcons.Lock,
                        16.sp,
                        FontWeight(500),
                        24.dp,
                        onChangePassword
                    )
                }
                HorizontalDivider(thickness = 1.dp, color = LightGray)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(start = 8.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppLabel(
                        "Log Out",
                        AppIcons.Logout,
                        16.sp,
                        FontWeight(500),
                        24.dp,
                        { showDialog = true },
                        Red
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = "Taha Notes v1.1",
            fontSize = 12.sp,
            color = Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        )
    }

    if (showDialog) {
        ActionPopup(
            title = "Log Out",
            message = "Are you sure you want to log out from the application?",
            onConfirm = {
                onLogout()
                showDialog = false
            },
            onCancel = { showDialog = false },
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
fun ProfileSection(imageRes: Int, name: String, email: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = "Profile",
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text = name, fontSize = 20.sp, fontWeight = FontWeight(700))
            AppLabel(email, AppIcons.Email, 12.sp, FontWeight(400), 15.dp, null, DarkGray)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SettingsScreenPreview() {
    SettingsScreen(
        uiState = SettingsUiState.Idle,
        name = "Taha Hamifar",
        email = "hamifar.taha@gmail.com",
        onBack = {},
        onChangePassword = {},
        onLogout = {}
    )
}
