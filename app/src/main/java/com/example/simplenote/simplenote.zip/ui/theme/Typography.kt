package com.example.simplenote.ui.theme

import androidx.compose.material3.Typography

// ستینگ تایپوگرافی مخصوص اپ (الان همون پیش‌فرض متریال3ه)
val AppTypography = Typography()
